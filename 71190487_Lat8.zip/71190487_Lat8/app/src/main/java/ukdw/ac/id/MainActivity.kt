package ukdw.ac.id
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem

import androidx.viewpager2.widget.ViewPager2

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupViewPager()

        setSupportActionBar(findViewById(R.id.toolbar_default))
        supportActionBar?.setDisplayShowTitleEnabled(false)


    }

    private fun setupViewPager() {
        val viewPager = findViewById<ViewPager2>(R.id.pager)
        val adapter = MyPagerAdapter(this, 3)
        viewPager.adapter = adapter
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_default,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.menu_home -> {
            val viewPager = findViewById<ViewPager2>(R.id.pager)

            viewPager.setCurrentItem(0);
            true
        }

        R.id.menu_profile -> {
            val viewPager = findViewById<ViewPager2>(R.id.pager)
            viewPager.setCurrentItem(1);
            true
        }

        R.id.menu_settings -> {
            val viewPager = findViewById<ViewPager2>(R.id.pager)
            viewPager.setCurrentItem(2);
            true
        }
        else -> {
            val viewPager = findViewById<ViewPager2>(R.id.pager)
            viewPager.setCurrentItem(0);
            super.onOptionsItemSelected(item)
        }
    }

}