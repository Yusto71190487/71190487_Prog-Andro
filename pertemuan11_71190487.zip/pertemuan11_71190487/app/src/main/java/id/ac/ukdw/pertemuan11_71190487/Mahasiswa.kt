package id.ac.ukdw.pertemuan11_71190487

data class Mahasiswa (var nama: String,var nim: Int, var ipk: Double)