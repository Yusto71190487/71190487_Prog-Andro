package ukdw.ac.id

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


import android.content.Intent


class MainActivity : AppCompatActivity() {
    private val PREFS_NAME = "preferences"
    private val PREF_UNAME = "Username"
    private val PREF_PASSWORD = "Password"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val mButton = findViewById<View>(R.id.submits) as Button

        mButton.setOnClickListener {

            var usernames = findViewById(R.id.username) as EditText
            var passwords = findViewById(R.id.password) as EditText

            val UserName = usernames.text.toString()
            val Password = passwords.text.toString()

            //Authenticate user
            if ((UserName.equals("admin") && Password.equals("123")) || (UserName.equals("andi") && Password.equals("111"))) {

                savePreferences(UserName,Password)
                Toast.makeText(this@MainActivity, "berhasil login", Toast.LENGTH_LONG).show()


                val intent = Intent(this@MainActivity, WelcomeActivity::class.java)
                startActivity(intent)
//                finish()
            } else {
                Toast.makeText(this@MainActivity, "gagal login", Toast.LENGTH_LONG).show()
            }

        }
    }


    private fun savePreferences(username: String, password: String) {
        val settings = getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )
        val editor = settings.edit()

        // Edit and commit
        println("onPause save name: $username")
        println("onPause save password: $password")
        editor.putString(PREF_UNAME, username)
        editor.putString(PREF_PASSWORD, password)
        editor.commit()
    }

}