package ukdw.ac.id

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity



class WelcomeActivity : AppCompatActivity() {
    var btnExit: Button? = null

    private val PREFS_NAME = "preferences"
    private val PREF_UNAME = "Username"
    private val PREF_PASSWORD = "Password"

    private val DefaultUnameValue = ""
    private var UnameValue: String? = null

    private val DefaultPasswordValue = ""
    private var PasswordValue: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        btnExit = findViewById<View>(R.id.logout) as Button

        val textView: TextView = findViewById(R.id.welcome_text) as TextView
        loadPreferences()

        textView.text = getString(R.string.welcome_messages, UnameValue)
        btnExit!!.setOnClickListener {
            Toast.makeText(this@WelcomeActivity, "Berhasil keluar", Toast.LENGTH_LONG)
            finish()
        }


    }



    private fun loadPreferences() {
        val settings = getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

        // Get value
        UnameValue = settings.getString(PREF_UNAME, DefaultUnameValue)
        PasswordValue = settings.getString(PREF_PASSWORD, DefaultPasswordValue)
    }
}