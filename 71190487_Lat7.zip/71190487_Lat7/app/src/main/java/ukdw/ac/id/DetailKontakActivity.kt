package ukdw.ac.id

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.content.Intent
import android.view.MenuItem
import androidx.appcompat.app.ActionBar


class DetailKontakActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_kontak)




        getSupportActionBar()?.setDisplayHomeAsUpEnabled(true);

        val nama_i = intent.getStringExtra("nama")
        val no_telp_i = intent.getStringExtra("no_telp")
        val alamat_i = intent.getStringExtra("alamat")

        val nama = findViewById<TextView>(R.id.dtNama)
        val no_telp = findViewById<TextView>(R.id.dtNomor)
        val alamat = findViewById<TextView>(R.id.dtAlamat)

        nama.text = "Nama : " + nama_i
        no_telp.text = "No Telp : " + no_telp_i
        alamat.text = "Alamat : " + alamat_i

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val myIntent = Intent(applicationContext, MainActivity::class.java)
        startActivityForResult(myIntent, 0)
        return true
    }


}