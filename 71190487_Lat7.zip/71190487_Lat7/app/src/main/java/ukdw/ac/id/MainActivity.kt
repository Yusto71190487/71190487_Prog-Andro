package ukdw.ac.id

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listKontak = ArrayList<Kontak>()
        listKontak.add(Kontak(1, "Yuniar Giffari Bachri", "082134971243", "Tangerang"))
        listKontak.add(Kontak(2, "Budi Sujadmiko", "021341241234", "Jakarta"))
        listKontak.add(Kontak(3, "Michael Enderson", "03212321231", "Bandung"))

        val rvKontak = findViewById<RecyclerView>(R.id.knListKontak)
        rvKontak.layoutManager = LinearLayoutManager(this)
        val adapter = KontakAdapter(listKontak)
        rvKontak.adapter = adapter
    }
}