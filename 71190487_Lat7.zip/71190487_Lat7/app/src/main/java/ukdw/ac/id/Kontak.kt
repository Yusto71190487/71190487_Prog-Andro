package ukdw.ac.id

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView

data class Kontak(val no: Int, val nama: String, val no_telp: String, val alamat: String)


class KontakAdapter(val listKontak: ArrayList<Kontak>) :
    RecyclerView.Adapter<KontakAdapter.KontakHolder>() {

    class KontakHolder(val v: View) : RecyclerView.ViewHolder(v) {
        var kontak: Kontak? = null

        fun bindView(kontak: Kontak) {
            this.kontak = kontak
            v.findViewById<TextView>(R.id.knTitle).text = "#${kontak.no} ${kontak.nama}"
            v.findViewById<TextView>(R.id.knNomor).text = kontak.no_telp.toString()
            v.findViewById<TextView>(R.id.knTitle).text = "#${kontak.no} ${kontak.nama}"


            v.setOnClickListener {
                val i = Intent(v.context, DetailKontakActivity::class.java)
                i.putExtra("no", kontak.no)
                i.putExtra("no_telp", kontak.no_telp)
                i.putExtra("nama", kontak.nama)
                i.putExtra("alamat", kontak.alamat)
                v.context.startActivity(i)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KontakAdapter.KontakHolder {
        //memilih file layout XML yang akan dijadikan container
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_kontak, parent, false)
        return KontakHolder(v)
    }

    override fun onBindViewHolder(holder: KontakAdapter.KontakHolder, position: Int) {
        //memasang data ke dalam file layout XML yang telah dipilih
        holder.bindView(listKontak[position])
    }

    override fun getItemCount(): Int {
    //mengembalikan jumlah item yang terdapat pada RecyclerView
        return listKontak.size
    }
}