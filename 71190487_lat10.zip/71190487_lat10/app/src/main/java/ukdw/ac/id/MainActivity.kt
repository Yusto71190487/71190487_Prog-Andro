package ukdw.ac.id

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.BaseColumns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import ukdw.ac.id.DatabaseContract.*

class MainActivity : AppCompatActivity() {
    lateinit var db: SQLiteDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val dbHelper = DatabaseHelper(this)
        db = dbHelper.writableDatabase

        val etNama = findViewById<EditText>(R.id.etNama)
        val etUsia = findViewById<EditText>(R.id.etUsia)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)
        val btnHapus = findViewById<Button>(R.id.btnHapus)
        val btnCari = findViewById<Button>(R.id.btnCari)

        btnSimpan.setOnClickListener {
            saveData(etNama.text.toString(), etUsia.text.toString())
        }

        btnCari.setOnClickListener {
            refreshData(etNama.text.toString(), etUsia.text.toString())
        }

        btnHapus.setOnClickListener {
            deleteData(etNama.text.toString(), etUsia.text.toString())
        }

        refreshData()
    }

    fun saveData(nama: String, usia: String){
        val values = ContentValues().apply {
            put(Penduduk.COLUMN_NAME_NAMA, nama)
            put(Penduduk.COLUMN_NAME_USIA, usia)
        }
        db.insert(Penduduk.TABLE_NAME, null, values)
        refreshData()
    }
    fun deleteData(nama: String, usia: String){
        val selection = "${Penduduk.COLUMN_NAME_NAMA} LIKE ? OR "+
                "${Penduduk.COLUMN_NAME_USIA} LIKE ?"
        val selectionArgs = arrayOf(nama, usia)
        val deletedRows = db.delete(Penduduk.TABLE_NAME, selection, selectionArgs)
        refreshData()
    }



    fun refreshData(nama: String?= null, usia: String? = null) {
        val columns = arrayOf(
            BaseColumns._ID,
            Penduduk.COLUMN_NAME_NAMA,
            Penduduk.COLUMN_NAME_USIA
        )
        var where: String? = null
        if(nama != null){
            where = Penduduk.COLUMN_NAME_NAMA + " LIKE '%" + nama + "%'"
        }
        if(usia != null){
            if(where != null){
                where += " OR "
            }
            where += Penduduk.COLUMN_NAME_USIA + " LIKE '%" + usia + "%'"
        }
        val cursor = db.query(
            Penduduk.TABLE_NAME,
            columns,
            where,
            null,
            null,
            null,
            null
        )
        var result = ""
        with(cursor) {
            while (moveToNext()) {
                result += "${getString(getColumnIndexOrThrow(Penduduk.COLUMN_NAME_NAMA))}"+
                        "-${getString(getColumnIndexOrThrow(Penduduk.COLUMN_NAME_USIA))}th\n"


            }
        }
        val tvHasil = findViewById<TextView>(R.id.tvHasil)
        tvHasil.text = result

    }
}